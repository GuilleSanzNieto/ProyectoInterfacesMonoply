1. Hacer `git pull` para bajar todos los cambios desde github
2. Ejecutar `npm install`para instalar todas las dependencias dle proyecto
3. Ejecutar `npm run dev` para inicializar el servidor con el proyecto